import socket
import time
import random

# Cấu hình client
HOST = "localhost"  # Địa chỉ server (có thể thay bằng IP của server)
PORT = 12345  # Cổng kết nối

# Tạo socket TCP
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Kết nối đến server
client_socket.connect((HOST, PORT))

# Vòng lặp gửi dữ liệu
for _ in range(5):  # Gửi 5 lần
    temp = random.randint(25, 35)  # Sinh nhiệt độ ngẫu nhiên
    message = f"Nhiệt độ: {temp}°C"

    # Gửi dữ liệu đến server
    client_socket.send(message.encode())
    print(f"[CLIENT] Gửi: {message}")

    # Chờ 2 giây trước khi gửi tiếp
    time.sleep(2)

# Đóng kết nối sau khi gửi xong
client_socket.close()

