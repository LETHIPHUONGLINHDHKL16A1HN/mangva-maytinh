pip install paho-mqtt matplotlib

import csv
import time
import random
from datetime import datetime

file_path = "sensor_data.csv"

# Nếu file chưa tồn tại, tạo và thêm dòng tiêu đề
try:
    with open(file_path, 'x', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['timestamp', 'temperature', 'humidity'])
        print("✅ Đã tạo file sensor_data.csv")
except FileExistsError:
    print("ℹ️ File đã tồn tại, sẽ thêm dữ liệu mới...")

# Vòng lặp ghi dữ liệu liên tục mỗi 5 giây
while True:
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    temperature = round(random.uniform(25, 35), 2)  # Nhiệt độ giả lập từ 25 đến 35 °C
    humidity = round(random.uniform(50, 80), 2)     # Độ ẩm giả lập từ 50 đến 80 %

    with open(file_path, 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([timestamp, temperature, humidity])
        print(f"📥 Đã ghi: {timestamp}, {temperature}°C, {humidity}%")

    time.sleep(5)
